# An "init" file is needed here but not in any other test directories. This is
# because the module "test_parser.py" is imported by "test_select.py" at the
# top level.
